<!DOCTYPE html>
<html lang="de">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My HTML Page</title>
  <link rel="stylesheet" type="text/css" title="Cool stylesheet" href="style.css">

  <style>
    * {
      box-sizing:border-box;
      font-family: monospace;
      /*font-family:courier;*/
    }

    #oben,#unten {
      width:96%;
      height:30vh;
      background: blue;
      border-radius: 8px;
      margin:2vh;
      box-sizing:border-box;
    }
    #unten {
      height:64vh;
    }

    .rahmen {
      font-size:1.5vw;
      width: 50%;
      background: #eee;
      border: 1px solid blue;
      height:100%;
      float:left;
    }

    .lekt_button {
      white-space: nowrap;
      border: 2px solid red;
      background: #ccc;
      width: 47%;
      padding: 1%;
      border-radius: 4px;
      margin:0.5%;
      float: left;
    }

    .lekt_mark {
      border: 1px solid blue;
      border-radius: 2px;

      background:red;
      width: 5%;

      float: left;

    }

    .lekt_strip {

      border-radius: 2px;
      color: green;
      width: 64px;
      float: left;
    }

    .lekt_text {
      border: 1px solid red;
      background: #eee;
      margin-left:9%;
      padding-left:2%;
      overflow-x: hidden;

    }

  </style>



</head>

<body>
  <div id="oben">



  </div>

  <div id="unten">
    <div class="rahmen">
    <?php
      for ($i=0;$i<23;$i++) {
        echo '
        <div class="lekt_button">
          <div class="lekt_mark">
            &nbsp;
          </div>
          <div class="lekt_text">
            Lektion '.($i+1).': ASDFg ljhlhjlk
          </div>
        </div>';
      }
      ?>
    </div>

    <div class="rahmen" >
      <?php
      for ($i=0;$i<18;$i++) {
        echo '
        <div class="lekt_button" style="float:right">
          <div class="lekt_mark">
            &nbsp;
          </div>
          <div class="lekt_text">
            Übung'.($i+1).': ASDFg ljhlhjlk
          </div>
        </div>';
      }
      ?>
    </div>
</div>



</body>

</html>
